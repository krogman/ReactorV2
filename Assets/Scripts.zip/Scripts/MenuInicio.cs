using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MenuInicio : MonoBehaviour
{

    public GameObject panel;

    public void salir(){
        Application.Quit();
    }
}
