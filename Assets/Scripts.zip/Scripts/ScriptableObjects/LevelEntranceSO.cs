using UnityEngine;

[CreateAssetMenu(fileName = "NewLevel", menuName = "Scriptable Objects/Level/Level Entrance")]
public class LevelEntranceSO : ScriptableObject 
{
}
