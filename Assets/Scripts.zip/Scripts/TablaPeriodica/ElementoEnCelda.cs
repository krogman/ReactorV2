using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ElementoEnCelda : MonoBehaviour
{
    public Elemento elemento;
    
}
